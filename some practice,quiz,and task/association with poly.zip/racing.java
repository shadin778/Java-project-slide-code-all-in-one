import java.lang.*;
public class racing extends car
{
	private String speed;
	private String size;
	public racing()
	{
		System.out.println("Empty cons racing");
	}
	public racing(String model, String price, String speed , String size)
	{
		super(model,price);
		this.speed=speed;
		this.speed=speed;
		System.out.println("para cons for racing");
		
	}
	public void setspeed(String Speed)
	{
		this.speed=speed;
	}
	public void setsize(String size)
	{
		this.size=size;
	}
	public String getspeed()
	{
		return speed;
	}
	public String getsize()
	{
		return size;
	}
	public void display()
	{
		super.display();
		System.out.println("Speed : "+speed);
		System.out.println("Size : "+size);
	}
	
	
}