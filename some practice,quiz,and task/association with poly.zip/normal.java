import java.lang.*;
public class normal extends car
{
	private String wYear;
	private String safety;
	public normal()
	{
		System.out.println("Empty for Normal");
	}
	public normal(String model, String price, String wYear, String safety)
	{
		super(model, price);
		this.wYear=wYear;
		this.safety=safety;
		System.out.println("Para for Normal");
	}
	public void setwYear(String wYear)
	{
		this.wYear=wYear;
	}
	public void setsaftey(String safety)
	{
		this.safety=safety;
	}
	
	public String getwYear()
	{
		return wYear;
	}
	public String getsafety()
	{
		return safety;
	}
	
	public void display()
	{
		super.display();
		System.out.println("warranty "+wYear);
		System.out.println("safety "+safety);
	}
	
	
	
}