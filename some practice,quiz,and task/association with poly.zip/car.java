import java.lang.*;
public class car 
{
	private String model;
	private String price;
	
	
	public car ()
	{
		System.out.println("Empty cons for car");
	}
	public car(String model, String price)
	{
		this.model= model;
		this.price= price;
		
		System.out.println("Para cons for car");
	}
	
	public void setmodel(String model)
	{
		this.model=model;
	}
	public void setprice(String price)
	{
		this.price=price;
	}
	public String getmodel()
	{
		return model;
	}
	public String getprice()
	{
		return price;
	}
	
	public void display()
	{
		System.out.println("Model : "+model);
		System.out.println("Price : "+price);
	}
	
}