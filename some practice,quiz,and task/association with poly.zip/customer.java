import java.lang.*;
public class customer 
{
	private String name;
	private car cc[];
	public customer()
	{
		System.out.println("Empty cons for customer");
	}
	public customer(String name, int size)
	{
		this.name=name;
		cc=new car[size];
		System.out.println("para cons for customer");
	}
	public void setname(String name)
	{
		this.name=name;
	}
	public String getname()
	{
		return name;
	}
	public void insertcc(car a)
	{
		int flag=0;
		for(int i=0 ; i<cc.length; i++)
		{
			if(cc[i]==null)
			{
				cc[i]=a;
				flag=1;
				break;
			}
		}
		
		if(flag ==1)
		{
			System.out.println("Inserted");
		}
		else
		{
			System.out.println("NOT Inserted");
		}
	}
	
	public void deletecc(car b)
	{
		int f=0;
		for (int i=0; i<cc.length; i++)
		{
			if(cc[i]==b)
			{
				cc[i]=null;
				f=1;
				break;
			}
			if(f==1)
			{
				System.out.println("Deleted");
			}
			else 
			{
				System.out.println("Not Deleted ");
			}
		}
	}
	
	
	public void display()
	{
		System.out.println("Name: "+name);
		for(int i=0;i<cc.length;i++)
		{
			if(cc[i]!=null)
			{
				cc[i].display();
			}
			else{System.out.println("Index empty");}
		}
	}
	
}