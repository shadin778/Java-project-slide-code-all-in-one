import java.lang.*;
public class start
{
	public static void main(String[] args)
	{
		car c1=new racing("BMW", "145k USD","250Kmph","L x W x H: 4319 x 1799 x 1434 mm");
		car c2=new racing("SLS AMG","1M USD", "315Kmph", "length of 4638mm, width of 1939mm and a wheelbase of 2680mm");
		car n1=new normal("Hyundai I20","1.94 Lakh","3 Years","8.84 points out of 17 for adult occupants");
		car n2=new normal("Maruti Baleno","5 lakh","2 Years","5 Star");
		customer P=new customer("APURBO  ",10);
		P.insertcc(c1);
		P.insertcc(c2);
		P.insertcc(n1);
		P.insertcc(n2);
		
		P.display();
	}	
}