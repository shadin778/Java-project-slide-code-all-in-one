import java.lang.*;
import java.util.*;

public class Start{
	
	public static void main(String[] args)
	{
		Account a1=new Account(500);
		a1.display();
		Scanner myobj=new Scanner(System.in);
		Account a2=new Account();
		a2.ainput(myobj);
		a2.display();
		
		
	}
}