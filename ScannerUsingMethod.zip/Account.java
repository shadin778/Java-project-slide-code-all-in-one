import java.lang.*;
import java.util.*;

public class Account
{
	
	public double amount;
	
	public Account()
	{
		System.out.println("Empty");
	}
	public Account(double amount)
	{
		System.out.println("para");
		this.amount=amount;
	}
	public void setamount(double amount)
	{
		this.amount=amount;
	}
	public double getamount()
	{
		return amount;
	}
	public void ainput(Scanner obj)
	{
		System.out.println("Give input");
		amount=obj.nextDouble();
	}
	public void display()
	{
		System.out.println("This is"+amount);
	}
}